import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Flag,
  CheckCircle2,
  AlertCircle,
  Star
} from 'lucide-react';
import { useState } from 'react';
import { fechasImportantes } from '@/data/actividades';

export function CalendarioElectoral() {
  const [date, setDate] = useState<Date | undefined>(new Date());

  // Crear un mapa de fechas importantes
  const fechasMap = new Map<string, typeof fechasImportantes[0]>();
  fechasImportantes.forEach(fecha => {
    fechasMap.set(fecha.fecha, fecha);
  });

  // Función para verificar si una fecha es importante
  const isFechaImportante = (date: Date) => {
    const fechaStr = date.toISOString().split('T')[0];
    return fechasMap.has(fechaStr);
  };

  const tipoColors: Record<string, string> = {
    inicio: 'bg-blue-500',
    fin: 'bg-red-500',
    limite: 'bg-amber-500',
    jornada: 'bg-purple-500',
    otro: 'bg-slate-500'
  };

  const tipoLabels: Record<string, string> = {
    inicio: 'Inicio',
    fin: 'Fin',
    limite: 'Fecha Límite',
    jornada: 'Jornada Electoral',
    otro: 'Otro'
  };

  const tipoIcons: Record<string, React.ElementType> = {
    inicio: Flag,
    fin: CheckCircle2,
    limite: AlertCircle,
    jornada: Star,
    otro: CalendarIcon
  };

  // Fecha seleccionada
  const fechaSeleccionada = date ? fechasMap.get(date.toISOString().split('T')[0]) : null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Calendario Electoral</h2>
        <p className="text-slate-500 mt-1">
          Fechas importantes de las Elecciones Generales 2026
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Calendario */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              Calendario
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border"
              modifiers={{
                importante: (date) => isFechaImportante(date),
              }}
              modifiersStyles={{
                importante: {
                  fontWeight: 'bold',
                  backgroundColor: '#fef3c7',
                  color: '#92400e',
                  borderRadius: '50%'
                }
              }}
            />
            
            {/* Leyenda */}
            <div className="mt-4 flex flex-wrap gap-3">
              {Object.entries(tipoLabels).map(([tipo, label]) => (
                <div key={tipo} className="flex items-center gap-1.5">
                  <div className={`w-3 h-3 rounded-full ${tipoColors[tipo]}`} />
                  <span className="text-xs text-slate-600">{label}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Detalle de Fecha Seleccionada */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Detalle
            </CardTitle>
          </CardHeader>
          <CardContent>
            {fechaSeleccionada ? (
              <div className="space-y-4">
                <div className={`p-4 rounded-lg ${tipoColors[fechaSeleccionada.tipo]} bg-opacity-10 border`}
                     style={{ borderColor: tipoColors[fechaSeleccionada.tipo].replace('bg-', '') }}>
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${tipoColors[fechaSeleccionada.tipo]}`}>
                      <Star className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <Badge className={`${tipoColors[fechaSeleccionada.tipo]} text-white mb-2`}>
                        {tipoLabels[fechaSeleccionada.tipo]}
                      </Badge>
                      <h3 className="text-lg font-semibold text-slate-900">
                        {fechaSeleccionada.titulo}
                      </h3>
                      <p className="text-slate-600 mt-1">
                        {fechaSeleccionada.descripcion}
                      </p>
                      <p className="text-sm text-slate-500 mt-3">
                        <CalendarIcon className="h-4 w-4 inline mr-1" />
                        {new Date(fechaSeleccionada.fecha).toLocaleDateString('es-PE', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 mb-4">
                  <CalendarIcon className="h-8 w-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-1">
                  Selecciona una fecha
                </h3>
                <p className="text-slate-500">
                  Haz clic en una fecha del calendario para ver más detalles
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Lista de Todas las Fechas Importantes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Todas las Fechas Importantes</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y">
            {fechasImportantes
              .sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime())
              .map((fecha, index) => {
                const Icon = tipoIcons[fecha.tipo];
                return (
                  <div 
                    key={index}
                    className="p-4 hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`p-2 rounded-lg ${tipoColors[fecha.tipo]} bg-opacity-20`}>
                        <Icon className={`h-5 w-5 ${tipoColors[fecha.tipo].replace('bg-', 'text-')}`} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-medium text-slate-900">{fecha.titulo}</h4>
                          <Badge className={`${tipoColors[fecha.tipo]} text-white text-xs`}>
                            {tipoLabels[fecha.tipo]}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-500 mt-1">{fecha.descripcion}</p>
                        <p className="text-sm text-slate-400 mt-2">
                          {new Date(fecha.fecha).toLocaleDateString('es-PE', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </CardContent>
      </Card>

      {/* Información de la Jornada Electoral */}
      <Card className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-white/20 rounded-lg">
              <Star className="h-8 w-8" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Jornada Electoral</h3>
              <p className="text-purple-100 mt-1">
                Domingo 12 de abril de 2026
              </p>
              <div className="flex flex-wrap gap-4 mt-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">Apertura: 7:00 a.m.</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">Cierre: 5:00 p.m.</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
