import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Bell, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  XCircle,
  X,
  Calendar,
  Clock
} from 'lucide-react';
import type { Alerta, Actividad } from '@/types';

interface AlertasPanelProps {
  alertas: Alerta[];
  actividadesUrgentes: Actividad[];
  actividadesProximas: Actividad[];
  onMarcarLeida: (id: string) => void;
  onEliminar: (id: string) => void;
  onVerActividad: (actividadId: string) => void;
}

const tipoIcons = {
  info: { icon: Info, color: 'text-blue-500', bg: 'bg-blue-50', border: 'border-blue-200' },
  warning: { icon: AlertTriangle, color: 'text-amber-500', bg: 'bg-amber-50', border: 'border-amber-200' },
  error: { icon: XCircle, color: 'text-red-500', bg: 'bg-red-50', border: 'border-red-200' },
  success: { icon: CheckCircle2, color: 'text-emerald-500', bg: 'bg-emerald-50', border: 'border-emerald-200' }
};

export function AlertasPanel({ 
  alertas, 
  actividadesUrgentes,
  actividadesProximas,
  onMarcarLeida, 
  onEliminar,
  onVerActividad
}: AlertasPanelProps) {
  const alertasNoLeidas = alertas.filter(a => !a.leida);
  const alertasLeidas = alertas.filter(a => a.leida);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Alertas y Notificaciones</h2>
        <p className="text-slate-500 mt-1">
          Mantente informado sobre actividades importantes y fechas límite
        </p>
      </div>

      {/* Resumen de Alertas */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-l-4 border-l-red-500">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-red-100">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {actividadesUrgentes.length}
                </p>
                <p className="text-sm text-slate-500">Actividades Urgentes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-amber-100">
                <Clock className="h-6 w-6 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {actividadesProximas.length}
                </p>
                <p className="text-sm text-slate-500">Fechas Próximas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-blue-100">
                <Bell className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {alertasNoLeidas.length}
                </p>
                <p className="text-sm text-slate-500">Notificaciones Nuevas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Actividades Urgentes */}
      {actividadesUrgentes.length > 0 && (
        <Card className="border-red-200">
          <CardHeader className="bg-red-50">
            <CardTitle className="text-lg flex items-center gap-2 text-red-800">
              <AlertTriangle className="h-5 w-5" />
              Actividades de Prioridad Alta Pendientes
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-auto max-h-[300px]">
              <div className="divide-y">
                {actividadesUrgentes.map((actividad) => (
                  <div 
                    key={actividad.id}
                    className="p-4 hover:bg-slate-50 cursor-pointer transition-colors"
                    onClick={() => onVerActividad(actividad.id)}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <p className="font-medium text-slate-900">{actividad.titulo}</p>
                        <p className="text-sm text-slate-500 mt-1">{actividad.descripcion}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline" className="text-xs bg-red-100 text-red-700 border-red-200">
                            Prioridad Alta
                          </Badge>
                          <span className="text-xs text-slate-400">{actividad.proceso}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-slate-400" />
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Actividades con Fecha Próxima */}
      {actividadesProximas.length > 0 && (
        <Card className="border-amber-200">
          <CardHeader className="bg-amber-50">
            <CardTitle className="text-lg flex items-center gap-2 text-amber-800">
              <Calendar className="h-5 w-5" />
              Fechas Límite Próximas
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-auto max-h-[300px]">
              <div className="divide-y">
                {actividadesProximas.map((actividad) => (
                  <div 
                    key={actividad.id}
                    className="p-4 hover:bg-slate-50 cursor-pointer transition-colors"
                    onClick={() => onVerActividad(actividad.id)}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <p className="font-medium text-slate-900">{actividad.titulo}</p>
                        <p className="text-sm text-slate-500 mt-1">{actividad.descripcion}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline" className="text-xs bg-amber-100 text-amber-700 border-amber-200">
                            <Calendar className="h-3 w-3 mr-1" />
                            Límite: {actividad.fechaLimite && new Date(actividad.fechaLimite).toLocaleDateString('es-PE')}
                          </Badge>
                          <span className="text-xs text-slate-400">{actividad.proceso}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-slate-400" />
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Notificaciones del Sistema */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notificaciones del Sistema
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-auto max-h-[400px]">
            <div className="divide-y">
              {alertasNoLeidas.length === 0 && alertasLeidas.length === 0 && (
                <div className="p-8 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 mb-4">
                    <Bell className="h-8 w-8 text-slate-400" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 mb-1">
                    Sin notificaciones
                  </h3>
                  <p className="text-slate-500">
                    No tienes notificaciones pendientes
                  </p>
                </div>
              )}

              {alertasNoLeidas.map((alerta) => {
                const tipo = tipoIcons[alerta.tipo];
                const Icon = tipo.icon;
                return (
                  <div 
                    key={alerta.id}
                    className={`p-4 ${tipo.bg} border-l-4 ${tipo.border}`}
                  >
                    <div className="flex items-start gap-3">
                      <Icon className={`h-5 w-5 ${tipo.color} mt-0.5`} />
                      <div className="flex-1">
                        <p className="font-medium text-slate-900">{alerta.titulo}</p>
                        <p className="text-sm text-slate-600 mt-1">{alerta.mensaje}</p>
                        <p className="text-xs text-slate-400 mt-2">
                          {new Date(alerta.fecha).toLocaleString('es-PE')}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => onMarcarLeida(alerta.id)}
                        >
                          <CheckCircle2 className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => onEliminar(alerta.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}

              {alertasLeidas.length > 0 && (
                <>
                  <div className="px-4 py-2 bg-slate-50">
                    <p className="text-xs font-medium text-slate-500 uppercase">
                      Notificaciones leídas
                    </p>
                  </div>
                  {alertasLeidas.map((alerta) => {
                    const tipo = tipoIcons[alerta.tipo];
                    const Icon = tipo.icon;
                    return (
                      <div 
                        key={alerta.id}
                        className="p-4 opacity-60 hover:opacity-100 transition-opacity"
                      >
                        <div className="flex items-start gap-3">
                          <Icon className={`h-5 w-5 ${tipo.color} mt-0.5`} />
                          <div className="flex-1">
                            <p className="font-medium text-slate-900">{alerta.titulo}</p>
                            <p className="text-sm text-slate-600 mt-1">{alerta.mensaje}</p>
                            <p className="text-xs text-slate-400 mt-2">
                              {new Date(alerta.fecha).toLocaleString('es-PE')}
                            </p>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => onEliminar(alerta.id)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

import { ChevronRight } from 'lucide-react';
