import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { 
  Search, 
  Filter, 
  AlertTriangle,
  Calendar,
  FileText,
  ChevronRight,
  Shield,
  GraduationCap,
  Users,
  LayoutGrid,
  UserCheck,
  Truck,
  Vote,
  Archive,
  Flag
} from 'lucide-react';
import type { Actividad, ProcesoElectoral, FaseProceso } from '@/types';
import { procesosInfo } from '@/data/actividades';

interface ActividadesListProps {
  actividades: Actividad[];
  onToggleActividad: (id: string) => void;
  onToggleSubActividad: (actividadId: string, subId: string) => void;
}

const iconMap: Record<string, React.ElementType> = {
  Shield, GraduationCap, Users, LayoutGrid, UserCheck, Truck, Vote, Archive, Flag
};

const faseLabels: Record<FaseProceso, string> = {
  preparacion: 'Preparación',
  capacitacion: 'Capacitación',
  organizacion: 'Organización',
  ejecucion: 'Ejecución',
  cierre: 'Cierre'
};

const prioridadColors = {
  alta: 'bg-red-100 text-red-700 border-red-200',
  media: 'bg-amber-100 text-amber-700 border-amber-200',
  baja: 'bg-blue-100 text-blue-700 border-blue-200'
};

export function ActividadesList({ 
  actividades, 
  onToggleActividad,
  onToggleSubActividad 
}: ActividadesListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filtroProceso, setFiltroProceso] = useState<ProcesoElectoral | 'todos'>('todos');
  const [filtroFase, setFiltroFase] = useState<FaseProceso | 'todas'>('todas');
  const [filtroEstado, setFiltroEstado] = useState<'todas' | 'completadas' | 'pendientes'>('todas');

  const actividadesFiltradas = actividades.filter(actividad => {
    const cumpleBusqueda = actividad.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          actividad.descripcion.toLowerCase().includes(searchTerm.toLowerCase());
    const cumpleProceso = filtroProceso === 'todos' || actividad.proceso === filtroProceso;
    const cumpleFase = filtroFase === 'todas' || actividad.fase === filtroFase;
    const cumpleEstado = filtroEstado === 'todas' || 
                        (filtroEstado === 'completadas' && actividad.completada) ||
                        (filtroEstado === 'pendientes' && !actividad.completada);
    
    return cumpleBusqueda && cumpleProceso && cumpleFase && cumpleEstado;
  });

  const getProcesoInfo = (codigo: ProcesoElectoral) => {
    return procesosInfo.find(p => p.codigo === codigo) || procesosInfo[0];
  };

  const getProgresoSubActividades = (actividad: Actividad) => {
    const completadas = actividad.subActividades.filter(s => s.completada).length;
    const total = actividad.subActividades.length;
    return { completadas, total, porcentaje: total > 0 ? Math.round((completadas / total) * 100) : 0 };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Actividades</h2>
          <p className="text-slate-500 mt-1">
            Gestiona todas las tareas de tu proceso como CLV/RLV
          </p>
        </div>

        {/* Filtros */}
        <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Buscar actividades..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={filtroProceso} onValueChange={(v) => setFiltroProceso(v as ProcesoElectoral | 'todos')}>
            <SelectTrigger className="w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Proceso" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos los procesos</SelectItem>
              {procesosInfo.map(p => (
                <SelectItem key={p.codigo} value={p.codigo}>{p.nombre}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filtroFase} onValueChange={(v) => setFiltroFase(v as FaseProceso | 'todas')}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Fase" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas las fases</SelectItem>
              <SelectItem value="preparacion">Preparación</SelectItem>
              <SelectItem value="capacitacion">Capacitación</SelectItem>
              <SelectItem value="organizacion">Organización</SelectItem>
              <SelectItem value="ejecucion">Ejecución</SelectItem>
              <SelectItem value="cierre">Cierre</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filtroEstado} onValueChange={(v) => setFiltroEstado(v as typeof filtroEstado)}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todos</SelectItem>
              <SelectItem value="pendientes">Pendientes</SelectItem>
              <SelectItem value="completadas">Completadas</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Resultados */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-500">
          Mostrando {actividadesFiltradas.length} de {actividades.length} actividades
        </p>
        {(filtroProceso !== 'todos' || filtroFase !== 'todas' || filtroEstado !== 'todas' || searchTerm) && (
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => {
              setFiltroProceso('todos');
              setFiltroFase('todas');
              setFiltroEstado('todas');
              setSearchTerm('');
            }}
          >
            Limpiar filtros
          </Button>
        )}
      </div>

      {/* Lista de Actividades */}
      <Accordion type="multiple" className="space-y-3">
        {actividadesFiltradas.map((actividad) => {
          const proceso = getProcesoInfo(actividad.proceso);
          const Icon = iconMap[proceso.icono] || Shield;
          const progreso = getProgresoSubActividades(actividad);
          
          return (
            <AccordionItem 
              key={actividad.id} 
              value={actividad.id}
              className={`border rounded-lg overflow-hidden ${actividad.completada ? 'bg-emerald-50/50' : 'bg-white'}`}
            >
              <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-slate-50">
                <div className="flex items-center gap-3 flex-1 text-left">
                  <Checkbox 
                    checked={actividad.completada}
                    onCheckedChange={() => onToggleActividad(actividad.id)}
                    onClick={(e) => e.stopPropagation()}
                    className="h-5 w-5"
                  />
                  <div 
                    className="p-1.5 rounded-md"
                    style={{ backgroundColor: `${proceso.color}20` }}
                  >
                    <Icon className="h-4 w-4" style={{ color: proceso.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`font-medium ${actividad.completada ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                        {actividad.titulo}
                      </span>
                      <Badge variant="outline" className={`text-xs ${prioridadColors[actividad.prioridad]}`}>
                        {actividad.prioridad}
                      </Badge>
                      {actividad.alertaActiva && (
                        <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          Alerta
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                      <span>{proceso.nombre}</span>
                      <span>•</span>
                      <span>{faseLabels[actividad.fase]}</span>
                      {actividad.fechaLimite && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Límite: {new Date(actividad.fechaLimite).toLocaleDateString('es-PE')}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500">
                      {progreso.completadas}/{progreso.total}
                    </span>
                    <ChevronRight className="h-4 w-4 text-slate-400 shrink-0 transition-transform" />
                  </div>
                </div>
              </AccordionTrigger>
              
              <AccordionContent className="px-4 pb-4">
                <div className="pl-10 space-y-4">
                  {/* Descripción */}
                  <p className="text-sm text-slate-600">
                    {actividad.descripcion}
                  </p>

                  {/* Documentos */}
                  {actividad.documentos && actividad.documentos.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {actividad.documentos.map((doc, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          <FileText className="h-3 w-3 mr-1" />
                          {doc}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Sub-actividades */}
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-slate-700">Pasos a seguir:</p>
                    <div className="space-y-1">
                      {actividad.subActividades
                        .sort((a, b) => a.orden - b.orden)
                        .map((sub) => (
                        <div 
                          key={sub.id}
                          className="flex items-start gap-2 p-2 rounded hover:bg-slate-100 transition-colors"
                        >
                          <Checkbox 
                            checked={sub.completada}
                            onCheckedChange={() => onToggleSubActividad(actividad.id, sub.id)}
                            className="mt-0.5"
                          />
                          <div className="flex-1">
                            <p className={`text-sm ${sub.completada ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                              {sub.titulo}
                            </p>
                            <p className="text-xs text-slate-500">
                              {sub.descripcion}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Notas */}
                  {actividad.notas && (
                    <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                      <p className="text-sm text-amber-800">
                        <strong>Nota:</strong> {actividad.notas}
                      </p>
                    </div>
                  )}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>

      {actividadesFiltradas.length === 0 && (
        <div className="text-center py-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 mb-4">
            <Search className="h-8 w-8 text-slate-400" />
          </div>
          <h3 className="text-lg font-medium text-slate-900 mb-1">
            No se encontraron actividades
          </h3>
          <p className="text-slate-500">
            Intenta ajustar los filtros de búsqueda
          </p>
        </div>
      )}
    </div>
  );
}
