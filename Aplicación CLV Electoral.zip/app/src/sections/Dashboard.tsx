import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  TrendingUp, 
  Bell,
  Calendar,
  AlertTriangle,
  Shield,
  GraduationCap,
  Users,
  LayoutGrid,
  UserCheck,
  Truck,
  Vote,
  Archive,
  Flag
} from 'lucide-react';
import type { Estadisticas } from '@/types';
import { procesosInfo } from '@/data/actividades';

interface DashboardProps {
  estadisticas: Estadisticas;
  actividadesUrgentes: number;
  actividadesProximas: number;
  alertasPendientes: number;
  onVerTodasActividades: () => void;
  onVerAlertas: () => void;
}

const iconMap: Record<string, React.ElementType> = {
  Shield,
  GraduationCap,
  Users,
  LayoutGrid,
  UserCheck,
  Truck,
  Vote,
  Archive,
  Flag
};

export function Dashboard({ 
  estadisticas, 
  actividadesUrgentes, 
  actividadesProximas,
  alertasPendientes,
  onVerTodasActividades,
  onVerAlertas
}: DashboardProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            Dashboard
          </h1>
          <p className="text-slate-500 mt-1">
            Resumen de tus actividades como Coordinador de Local de Votación
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Elecciones 2026
          </Badge>
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            CLV/RLV
          </Badge>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">
              Progreso General
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">
              {estadisticas.progresoGeneral}%
            </div>
            <Progress value={estadisticas.progresoGeneral} className="mt-2" />
            <p className="text-xs text-slate-500 mt-2">
              {estadisticas.completadas} de {estadisticas.totalActividades} actividades
            </p>
          </CardContent>
        </Card>

        <Card 
          className="border-l-4 border-l-red-500 cursor-pointer hover:shadow-md transition-shadow"
          onClick={onVerAlertas}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">
              Alertas Activas
            </CardTitle>
            <Bell className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">
              {alertasPendientes}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              {alertasPendientes > 0 ? 'Requiere atención' : 'Sin alertas pendientes'}
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">
              Actividades Urgentes
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">
              {actividadesUrgentes}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Prioridad alta pendiente
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-emerald-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">
              Próximas Fechas
            </CardTitle>
            <Calendar className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">
              {actividadesProximas}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              En los próximos 7 días
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Procesos Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Procesos Electorales</CardTitle>
          <p className="text-sm text-slate-500">
            Estado de cada proceso del Sistema de Gestión de la Calidad
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {procesosInfo.map((proceso) => {
              const Icon = iconMap[proceso.icono] || Shield;
              return (
                <div 
                  key={proceso.codigo}
                  className="flex items-start gap-3 p-3 rounded-lg border hover:bg-slate-50 transition-colors cursor-pointer"
                  onClick={onVerTodasActividades}
                >
                  <div 
                    className="p-2 rounded-lg"
                    style={{ backgroundColor: `${proceso.color}20` }}
                  >
                    <Icon className="h-5 w-5" style={{ color: proceso.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-900 text-sm">
                      {proceso.nombre}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {proceso.nombreCompleto}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Resumen por Estado */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-emerald-100">
                <CheckCircle2 className="h-6 w-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {estadisticas.completadas}
                </p>
                <p className="text-sm text-slate-500">Completadas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-amber-100">
                <Clock className="h-6 w-6 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {estadisticas.enProgreso}
                </p>
                <p className="text-sm text-slate-500">En Progreso</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-slate-100">
                <AlertCircle className="h-6 w-6 text-slate-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {estadisticas.pendientes}
                </p>
                <p className="text-sm text-slate-500">Pendientes</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
