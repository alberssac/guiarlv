import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Shield, 
  GraduationCap, 
  Users, 
  LayoutGrid, 
  UserCheck, 
  Truck, 
  Vote, 
  Archive, 
  Flag,
  BookOpen,
  FileText,
  CheckCircle2,
  AlertCircle,
  Info
} from 'lucide-react';
import { procesosInfo } from '@/data/actividades';

const iconMap: Record<string, React.ElementType> = {
  Shield, GraduationCap, Users, LayoutGrid, UserCheck, Truck, Vote, Archive, Flag
};

const procesoDetalles: Record<string, {
  objetivo: string;
  actividadesPrincipales: string[];
  documentosClave: string[];
  responsabilidades: string[];
  consejos: string[];
}> = {
  SP: {
    objetivo: 'Establecer medidas preventivas con el propósito de que los comicios se desarrollen en el orden correcto, garantizando el libre ejercicio del derecho al voto, el funcionamiento de las mesas de sufragio y la custodia de los locales de votación.',
    actividadesPrincipales: [
      'Presentarse ante el oficial de las FF.AA. a cargo de la patrulla',
      'Coordinar con efectivos de la PNP y FF.AA. una reunión previa',
      'Revisar conjuntamente la cartilla de instrucciones',
      'Elaborar planes de contingencia para evacuación',
      'Coordinar seguridad del material electoral y equipos informáticos',
      'Asegurar que todo el personal esté listo para trasladarse a la ODPE'
    ],
    documentosClave: [
      'Cartilla de instrucciones para FF.AA. y PNP',
      'Plan de contingencia del local de votación',
      'Directorio de contactos de seguridad'
    ],
    responsabilidades: [
      'Coordinar con fuerzas de seguridad',
      'Garantizar seguridad del material electoral',
      'Elaborar planes de emergencia',
      'Supervisar custodia del local de votación'
    ],
    consejos: [
      'Mantener comunicación constante con los oficiales de seguridad',
      'Identificar claramente las rutas de evacuación',
      'Tener a mano los números de emergencia',
      'Realizar simulacros si es posible'
    ]
  },
  CPO: {
    objetivo: 'Transferir conocimientos, actualizar información y fortalecer las habilidades y destrezas del personal contratado, con el propósito de garantizar que cada integrante cuente con las competencias necesarias para cumplir sus funciones.',
    actividadesPrincipales: [
      'Asistir a reuniones de reforzamiento programadas',
      'Participar en jornadas de entrenamiento práctico',
      'Registrar asistencia en formato FM10-GOECOR/CPO',
      'Rendir evaluaciones al término de cada reunión',
      'Practicar acondicionamiento del centro de acopio',
      'Practicar traslado de sobres y uso de formatos'
    ],
    documentosClave: [
      'FM10-GOECOR/CPO - Registro de asistencia',
      'Materiales de capacitación ONPE',
      'Evaluaciones de reforzamiento'
    ],
    responsabilidades: [
      'Asistir puntualmente a todas las sesiones',
      'Participar activamente en ejercicios prácticos',
      'Completar evaluaciones satisfactoriamente',
      'Aplicar conocimientos adquiridos'
    ],
    consejos: [
      'Tomar notas durante las capacitaciones',
      'Practicar los procedimientos varias veces',
      'Resolver dudas con los capacitadores',
      'Revisar materiales de estudio en casa'
    ]
  },
  CAE: {
    objetivo: 'Capacitar a miembros de mesa, personeros y otros actores electorales para garantizar un adecuado desempeño de sus funciones durante el proceso electoral.',
    actividadesPrincipales: [
      'Apoyar en organización de jornadas de capacitación',
      'Primera jornada: Domingo 29 de marzo de 2026',
      'Segunda jornada: Domingo 5 de abril de 2026',
      'Registrar capacitación en FM06-GOECOR/CAE',
      'Distribuir materiales de capacitación',
      'Supervisar locales de capacitación con FM12-GOECOR/CAE'
    ],
    documentosClave: [
      'FM06-GOECOR/CAE - Registro de capacitación de miembros de mesa',
      'FM12-GOECOR/CAE - Supervisión del local de capacitación',
      'Manual de instrucciones para miembros de mesa',
      'Afiche jornada de capacitación'
    ],
    responsabilidades: [
      'Organizar jornadas de capacitación',
      'Registrar asistencia de miembros de mesa',
      'Distribuir materiales de capacitación',
      'Supervisar adecuado desarrollo de capacitaciones'
    ],
    consejos: [
      'Verificar que todos los miembros de mesa asistan',
      'Tener material de contingencia disponible',
      'Coordinar con facilitadores con anticipación',
      'Prever espacios para personas con discapacidad'
    ]
  },
  CMS: {
    objetivo: 'Conformar las mesas de sufragio y determinar su ubicación dentro de los ambientes de los locales de votación, así como la ubicación de ambientes especiales.',
    actividadesPrincipales: [
      'Efectuar reconocimiento del local de votación',
      'Recibir formatos FM02, FM07 y FM04 del coordinador distrital',
      'Verificar disponibilidad del local y cantidad de aulas',
      'Identificar ambientes especiales (CA, PT, MTV, FF.AA., armería)',
      'Elaborar croquis del local en FM04-GOECOR/CMS',
      'Elaborar maestro de mesas en FM05-GOECOR/CMS'
    ],
    documentosClave: [
      'FM02-GOECOR/CMS - Ficha de verificación de local',
      'FM04-GOECOR/CMS - Croquis del local de votación',
      'FM05-GOECOR/CMS - Maestro de mesas de sufragio',
      'FM07-GOECOR/CMS - Acta de conformidad de uso',
      'Anexo 1 - Instrucciones para elaborar croquis'
    ],
    responsabilidades: [
      'Reconocer y verificar el local de votación',
      'Elaborar croquis detallado del local',
      'Asignar mesas a aulas de manera eficiente',
      'Identificar y señalizar ambientes especiales'
    ],
    consejos: [
      'Visitar el local con anticipación',
      'Tomar fotografías para referencia',
      'Medir distancias y verificar accesos',
      'Considerar flujo de electores al asignar mesas'
    ]
  },
  DMM: {
    objetivo: 'Designar a los ciudadanos que actuarán como miembros de mesa en cada mesa de sufragio, asegurando la conformación completa de cada mesa.',
    actividadesPrincipales: [
      'Verificar designación de presidente de mesa',
      'Verificar designación de secretario de mesa',
      'Verificar designación de tercer miembro',
      'Verificar designación de suplentes (1°, 2° y 3°)',
      'Confirmar que todas las mesas tienen miembros designados'
    ],
    documentosClave: [
      'Relación de miembros de mesa designados',
      'Formatos de designación'
    ],
    responsabilidades: [
      'Verificar completitud de designaciones',
      'Confirmar datos de miembros de mesa',
      'Coordinar reemplazos si es necesario'
    ],
    consejos: [
      'Verificar designaciones con anticipación',
      'Tener lista de contactos de suplentes',
      'Confirmar asistencia previa a la jornada'
    ]
  },
  DMS: {
    objetivo: 'Trasladar el material electoral y los equipos informáticos desde la ODPE hasta los locales de votación de manera segura y oportuna.',
    actividadesPrincipales: [
      'Recibir material de sufragio del coordinador distrital',
      'Recibir material de reserva y paquete del CLV',
      'Recibir señales, ánforas, cabinas y refrigerios',
      'Verificar coincidencia con mesas asignadas',
      'Firmar FM06-GOECOR/DMS de constancia de recepción',
      'Trasladar material al centro de acopio',
      'Recibir equipos informáticos (STAE) y firmar FM08-GOECOR/DMS'
    ],
    documentosClave: [
      'FM06-GOECOR/DMS - Constancia de recepción de material',
      'FM08-GOECOR/DMS - Constancia de recepción de equipos',
      'Relación de material de sufragio'
    ],
    responsabilidades: [
      'Recibir y verificar todo el material electoral',
      'Asegurar traslado al centro de acopio',
      'Garantizar custodia durante el traslado',
      'Reportar cualquier discrepancia'
    ],
    consejos: [
      'Verificar material en presencia de FF.AA. o PNP',
      'No dejar material desatendido',
      'Revisar sellos e integridad de cajas',
      'Tener lista de verificación completa'
    ]
  },
  JEL: {
    objetivo: 'Dirigir, organizar y supervisar todas las actividades del día de la jornada electoral, desde la instalación de mesas hasta el cierre y entrega del local.',
    actividadesPrincipales: [
      'Acondicionar centro de acopio (turno mañana y tarde)',
      'Señalizar y acondicionar el local de votación',
      'Entregar material a coordinadores de mesa',
      'Atender a fiscalizadores, observadores y personeros',
      'Orientar a electores durante la jornada',
      'Recibir documentos y materiales de mesas',
      'Entregar local en las mismas condiciones recibidas'
    ],
    documentosClave: [
      'FM02-GOECOR/JEL - Lista de chequeo de acondicionamiento',
      'Relación de electores por mesa',
      'Actas de instalación y cierre de mesas',
      'Formatos de entrega de material'
    ],
    responsabilidades: [
      'Acondicionar el local de votación',
      'Distribuir material electoral',
      'Atender a actores electorales',
      'Orientar a la ciudadanía',
      'Recibir y custodiar documentos electorales',
      'Entregar el local en buenas condiciones'
    ],
    consejos: [
      'Llegar temprano al local',
      'Tener un plan de contingencia',
      'Mantener calma ante imprevistos',
      'Documentar cualquier incidencia',
      'Comunicarse constantemente con la ODPE'
    ]
  },
  RME: {
    objetivo: 'Recoger y trasladar el material electoral desde los locales de votación hacia la ODPE de manera segura y ordenada.',
    actividadesPrincipales: [
      'Organizar materiales en centro de acopio',
      'Verificar integridad de sobres y sellos',
      'Coordinar traslado con FF.AA. y PNP',
      'Entregar en línea de recepción de ODPE',
      'Completar formatos de entrega'
    ],
    documentosClave: [
      'Formatos de entrega de material',
      'Actas de traslado',
      'Relación de documentos electorales'
    ],
    responsabilidades: [
      'Organizar materiales para traslado',
      'Verificar integridad de documentos',
      'Coordinar seguridad del traslado',
      'Entregar material en ODPE'
    ],
    consejos: [
      'No separarse del material en ningún momento',
      'Verificar que nada quede en el local',
      'Llevar lista de verificación',
      'Mantener comunicación con la ODPE'
    ]
  },
  CIO: {
    objetivo: 'Finalizar todas las actividades operativas y administrativas asignadas al CLV tras el proceso electoral.',
    actividadesPrincipales: [
      'Entregar informes finales',
      'Devolver materiales de trabajo (fotocheck, etc.)',
      'Confirmar asistencia final',
      'Completar documentación de cierre'
    ],
    documentosClave: [
      'Informes finales de actividades',
      'Formatos de devolución de materiales',
      'Constancia de asistencia final'
    ],
    responsabilidades: [
      'Completar documentación requerida',
      'Devolver materiales de la ONPE',
      'Asistir a cierre de actividades'
    ],
    consejos: [
      'Conservar copias de documentos importantes',
      'Solicitar constancia de trabajo',
      'Mantener contacto con la ODPE para consultas'
    ]
  }
};

export function GuiaProcesos() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Guía de Procesos</h2>
        <p className="text-slate-500 mt-1">
          Información detallada sobre cada proceso del Sistema de Gestión de la Calidad
        </p>
      </div>

      <Tabs defaultValue="SP" className="w-full">
        <TabsList className="flex flex-wrap h-auto gap-1">
          {procesosInfo.map((proceso) => (
            <TabsTrigger 
              key={proceso.codigo} 
              value={proceso.codigo}
              className="text-xs sm:text-sm"
            >
              {proceso.nombre}
            </TabsTrigger>
          ))}
        </TabsList>

        {procesosInfo.map((proceso) => {
          const detalles = procesoDetalles[proceso.codigo];
          const Icon = iconMap[proceso.icono] || Shield;
          
          return (
            <TabsContent key={proceso.codigo} value={proceso.codigo}>
              <Card>
                <CardHeader 
                  className="text-white"
                  style={{ backgroundColor: proceso.color }}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <Icon className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{proceso.nombreCompleto}</CardTitle>
                      <p className="text-white/80 text-sm mt-1">{proceso.codigo}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  {/* Objetivo */}
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-2">
                      <BookOpen className="h-5 w-5 text-blue-500" />
                      Objetivo
                    </h3>
                    <p className="text-slate-600">{detalles.objetivo}</p>
                  </div>

                  {/* Actividades Principales */}
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-3">
                      <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                      Actividades Principales
                    </h3>
                    <ul className="space-y-2">
                      {detalles.actividadesPrincipales.map((actividad, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-emerald-500 mt-1">•</span>
                          <span className="text-slate-600">{actividad}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="grid gap-6 md:grid-cols-2">
                    {/* Documentos Clave */}
                    <div>
                      <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-3">
                        <FileText className="h-5 w-5 text-amber-500" />
                        Documentos Clave
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {detalles.documentosClave.map((doc, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {doc}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Responsabilidades */}
                    <div>
                      <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-3">
                        <AlertCircle className="h-5 w-5 text-red-500" />
                        Responsabilidades
                      </h3>
                      <ul className="space-y-1">
                        {detalles.responsabilidades.map((resp, idx) => (
                          <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                            <span className="text-red-400">-</span>
                            {resp}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Consejos */}
                  <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                    <h3 className="text-lg font-semibold text-blue-900 flex items-center gap-2 mb-3">
                      <Info className="h-5 w-5" />
                      Consejos y Recomendaciones
                    </h3>
                    <ul className="space-y-2">
                      {detalles.consejos.map((consejo, idx) => (
                        <li key={idx} className="text-blue-800 flex items-start gap-2">
                          <span className="text-blue-500 mt-0.5">💡</span>
                          {consejo}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          );
        })}
      </Tabs>
    </div>
  );
}
