import { useState, useCallback, useMemo } from 'react';
import type { Actividad, Alerta, Estadisticas, ProcesoElectoral, FaseProceso } from '@/types';
import { actividades as actividadesIniciales, alertasIniciales } from '@/data/actividades';

export function useActividades() {
  const [actividades, setActividades] = useState<Actividad[]>(actividadesIniciales);
  const [alertas, setAlertas] = useState<Alerta[]>(alertasIniciales);
  const [filtroProceso, setFiltroProceso] = useState<ProcesoElectoral | 'todos'>('todos');
  const [filtroFase, setFiltroFase] = useState<FaseProceso | 'todas'>('todas');

  // Estadísticas
  const estadisticas: Estadisticas = useMemo(() => {
    const total = actividades.length;
    const completadas = actividades.filter(a => a.completada).length;
    const pendientes = actividades.filter(a => !a.completada).length;
    const enProgreso = actividades.filter(a => {
      const subCompletadas = a.subActividades.filter(s => s.completada).length;
      return subCompletadas > 0 && subCompletadas < a.subActividades.length;
    }).length;
    const alertasActivas = alertas.filter(a => !a.leida).length;
    const progresoGeneral = total > 0 ? Math.round((completadas / total) * 100) : 0;

    return {
      totalActividades: total,
      completadas,
      pendientes,
      enProgreso,
      alertasActivas,
      progresoGeneral
    };
  }, [actividades, alertas]);

  // Filtrar actividades
  const actividadesFiltradas = useMemo(() => {
    return actividades.filter(actividad => {
      const cumpleProceso = filtroProceso === 'todos' || actividad.proceso === filtroProceso;
      const cumpleFase = filtroFase === 'todas' || actividad.fase === filtroFase;
      return cumpleProceso && cumpleFase;
    });
  }, [actividades, filtroProceso, filtroFase]);

  // Agrupar actividades por proceso
  const actividadesPorProceso = useMemo(() => {
    const agrupadas: Record<ProcesoElectoral, Actividad[]> = {
      SP: [], CPO: [], CAE: [], CMS: [], DMM: [], DMS: [], JEL: [], RME: [], CIO: []
    };
    actividades.forEach(actividad => {
      agrupadas[actividad.proceso].push(actividad);
    });
    return agrupadas;
  }, [actividades]);

  // Agrupar actividades por fase
  const actividadesPorFase = useMemo(() => {
    const agrupadas: Record<FaseProceso, Actividad[]> = {
      preparacion: [],
      capacitacion: [],
      organizacion: [],
      ejecucion: [],
      cierre: []
    };
    actividades.forEach(actividad => {
      agrupadas[actividad.fase].push(actividad);
    });
    return agrupadas;
  }, [actividades]);

  // Marcar actividad como completada
  const toggleActividad = useCallback((actividadId: string) => {
    setActividades(prev => prev.map(actividad => {
      if (actividad.id === actividadId) {
        const nuevaCompletada = !actividad.completada;
        // Si se marca como completada, marcar todas las subactividades
        const nuevasSubActividades = actividad.subActividades.map(sub => ({
          ...sub,
          completada: nuevaCompletada
        }));
        return {
          ...actividad,
          completada: nuevaCompletada,
          subActividades: nuevasSubActividades
        };
      }
      return actividad;
    }));
  }, []);

  // Marcar subactividad como completada
  const toggleSubActividad = useCallback((actividadId: string, subActividadId: string) => {
    setActividades(prev => prev.map(actividad => {
      if (actividad.id === actividadId) {
        const nuevasSubActividades = actividad.subActividades.map(sub =>
          sub.id === subActividadId ? { ...sub, completada: !sub.completada } : sub
        );
        // Verificar si todas las subactividades están completadas
        const todasCompletadas = nuevasSubActividades.every(sub => sub.completada);
        return {
          ...actividad,
          subActividades: nuevasSubActividades,
          completada: todasCompletadas
        };
      }
      return actividad;
    }));
  }, []);

  // Agregar alerta
  const agregarAlerta = useCallback((alerta: Omit<Alerta, 'id' | 'fecha'>) => {
    const nuevaAlerta: Alerta = {
      ...alerta,
      id: `ALT-${Date.now()}`,
      fecha: new Date().toISOString()
    };
    setAlertas(prev => [nuevaAlerta, ...prev]);
  }, []);

  // Marcar alerta como leída
  const marcarAlertaLeida = useCallback((alertaId: string) => {
    setAlertas(prev => prev.map(alerta =>
      alerta.id === alertaId ? { ...alerta, leida: true } : alerta
    ));
  }, []);

  // Eliminar alerta
  const eliminarAlerta = useCallback((alertaId: string) => {
    setAlertas(prev => prev.filter(alerta => alerta.id !== alertaId));
  }, []);

  // Obtener actividades con alertas activas
  const actividadesConAlertas = useMemo(() => {
    return actividades.filter(a => a.alertaActiva);
  }, [actividades]);

  // Obtener actividades urgentes (prioridad alta y no completadas)
  const actividadesUrgentes = useMemo(() => {
    return actividades.filter(a => a.prioridad === 'alta' && !a.completada);
  }, [actividades]);

  // Obtener actividades próximas (con fecha límite cercana)
  const actividadesProximas = useMemo(() => {
    const hoy = new Date();
    const unaSemana = new Date(hoy.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    return actividades.filter(a => {
      if (a.completada || !a.fechaLimite) return false;
      const fechaLimite = new Date(a.fechaLimite);
      return fechaLimite <= unaSemana && fechaLimite >= hoy;
    });
  }, [actividades]);

  return {
    actividades,
    actividadesFiltradas,
    actividadesPorProceso,
    actividadesPorFase,
    actividadesConAlertas,
    actividadesUrgentes,
    actividadesProximas,
    alertas,
    estadisticas,
    filtroProceso,
    filtroFase,
    setFiltroProceso,
    setFiltroFase,
    toggleActividad,
    toggleSubActividad,
    agregarAlerta,
    marcarAlertaLeida,
    eliminarAlerta
  };
}
