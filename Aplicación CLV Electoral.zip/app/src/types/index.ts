// Tipos para la aplicación de Guía CLV

export interface Actividad {
  id: string;
  titulo: string;
  descripcion: string;
  proceso: ProcesoElectoral;
  fase: FaseProceso;
  fechaInicio?: string;
  fechaFin?: string;
  fechaLimite?: string;
  completada: boolean;
  prioridad: 'alta' | 'media' | 'baja';
  alertaActiva: boolean;
  subActividades: SubActividad[];
  documentos?: string[];
  responsables?: string[];
  notas?: string;
}

export interface SubActividad {
  id: string;
  titulo: string;
  descripcion: string;
  completada: boolean;
  orden: number;
}

export type ProcesoElectoral = 
  | 'SP'  // Seguridad del Proceso
  | 'CPO' // Capacitación del Personal de la ODPE
  | 'CAE' // Capacitación de Actores Electorales
  | 'CMS' // Conformación de Mesas de Sufragio
  | 'DMM' // Designación de Miembros de Mesa
  | 'DMS' // Despliegue de Material de Sufragio
  | 'JEL' // Jornada Electoral
  | 'RME' // Repliegue de Material Electoral
  | 'CIO'; // Cierre de la ODPE

export type FaseProceso = 
  | 'preparacion'
  | 'capacitacion'
  | 'organizacion'
  | 'ejecucion'
  | 'cierre';

export interface Alerta {
  id: string;
  tipo: 'info' | 'warning' | 'error' | 'success';
  titulo: string;
  mensaje: string;
  fecha: string;
  leida: boolean;
  actividadId?: string;
}

export interface FechaImportante {
  fecha: string;
  titulo: string;
  descripcion: string;
  tipo: 'inicio' | 'fin' | 'limite' | 'jornada' | 'otro';
}

export interface Estadisticas {
  totalActividades: number;
  completadas: number;
  pendientes: number;
  enProgreso: number;
  alertasActivas: number;
  progresoGeneral: number;
}

export interface ProcesoInfo {
  codigo: ProcesoElectoral;
  nombre: string;
  nombreCompleto: string;
  descripcion: string;
  color: string;
  icono: string;
}
