import type { Actividad, FechaImportante, ProcesoInfo, Alerta } from '@/types';

export const procesosInfo: ProcesoInfo[] = [
  {
    codigo: 'SP',
    nombre: 'SP',
    nombreCompleto: 'Seguridad del Proceso',
    descripcion: 'Establecer medidas preventivas para que los comicios se desarrollen en orden, garantizando el libre ejercicio del derecho al voto, el funcionamiento de las mesas de sufragio y la custodia de los locales de votación.',
    color: '#ef4444',
    icono: 'Shield'
  },
  {
    codigo: 'CPO',
    nombre: 'CPO',
    nombreCompleto: 'Capacitación del Personal de la ODPE',
    descripcion: 'Transferir conocimientos, actualizar información y fortalecer las habilidades del personal contratado para garantizar que cuenten con las competencias necesarias.',
    color: '#3b82f6',
    icono: 'GraduationCap'
  },
  {
    codigo: 'CAE',
    nombre: 'CAE',
    nombreCompleto: 'Capacitación de Actores Electorales',
    descripcion: 'Capacitar a miembros de mesa, personeros, fiscalizadores y otros actores involucrados en el proceso electoral.',
    color: '#8b5cf6',
    icono: 'Users'
  },
  {
    codigo: 'CMS',
    nombre: 'CMS',
    nombreCompleto: 'Conformación de Mesas de Sufragio',
    descripcion: 'Conformar las mesas de sufragio y determinar su ubicación dentro de los ambientes de los locales de votación.',
    color: '#10b981',
    icono: 'LayoutGrid'
  },
  {
    codigo: 'DMM',
    nombre: 'DMM',
    nombreCompleto: 'Designación de Miembros de Mesa',
    descripcion: 'Designar a los ciudadanos que actuarán como miembros de mesa en cada mesa de sufragio.',
    color: '#f59e0b',
    icono: 'UserCheck'
  },
  {
    codigo: 'DMS',
    nombre: 'DMS',
    nombreCompleto: 'Despliegue de Material de Sufragio',
    descripcion: 'Trasladar el material electoral y los equipos informáticos desde la ODPE hasta los locales de votación.',
    color: '#06b6d4',
    icono: 'Truck'
  },
  {
    codigo: 'JEL',
    nombre: 'JEL',
    nombreCompleto: 'Jornada Electoral',
    descripcion: 'Día en que los ciudadanos emiten su voto. Incluye instalación de mesas, sufragio, escrutinio y traslado de materiales.',
    color: '#ec4899',
    icono: 'Vote'
  },
  {
    codigo: 'RME',
    nombre: 'RME',
    nombreCompleto: 'Repliegue de Material Electoral',
    descripcion: 'Recoger y trasladar el material electoral desde los locales de votación hacia la ODPE.',
    color: '#6366f1',
    icono: 'Archive'
  },
  {
    codigo: 'CIO',
    nombre: 'CIO',
    nombreCompleto: 'Cierre de la ODPE',
    descripcion: 'Finalizar todas las actividades operativas y administrativas de la ODPE tras el proceso electoral.',
    color: '#64748b',
    icono: 'Flag'
  }
];

export const actividades: Actividad[] = [
  // SEGURIDAD DEL PROCESO (SP)
  {
    id: 'SP-001',
    titulo: 'Coordinación con FF.AA. y PNP',
    descripcion: 'Presentarse ante el oficial de las FF.AA. a cargo de la patrulla y ante el efectivo policial de mayor rango que estará custodiando los exteriores del local de votación.',
    proceso: 'SP',
    fase: 'preparacion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'SP-001-1', titulo: 'Identificar al oficial de FF.AA. a cargo', descripcion: 'Ubicar y presentarse ante el oficial responsable', completada: false, orden: 1 },
      { id: 'SP-001-2', titulo: 'Identificar al efectivo PNP de mayor rango', descripcion: 'Ubicar y presentarse ante el responsable de la PNP', completada: false, orden: 2 },
      { id: 'SP-001-3', titulo: 'Coordinar reunión previa', descripcion: 'Organizar reunión un día antes del proceso electoral', completada: false, orden: 3 },
      { id: 'SP-001-4', titulo: 'Revisar cartilla de instrucciones', descripcion: 'Revisar conjuntamente el contenido de la cartilla', completada: false, orden: 4 }
    ],
    documentos: ['Cartilla de instrucciones para FF.AA. y PNP']
  },
  {
    id: 'SP-002',
    titulo: 'Plan de contingencia para evacuación',
    descripcion: 'Elaborar planes de contingencia para la evacuación del personal en situación de emergencia.',
    proceso: 'SP',
    fase: 'preparacion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'SP-002-1', titulo: 'Identificar rutas de evacuación', descripcion: 'Reconocer las rutas de salida del local', completada: false, orden: 1 },
      { id: 'SP-002-2', titulo: 'Identificar puntos de reunión', descripcion: 'Definir puntos de reunión seguros', completada: false, orden: 2 },
      { id: 'SP-002-3', titulo: 'Coordinar con personal de seguridad', descripcion: 'Validar plan con FF.AA. y PNP', completada: false, orden: 3 }
    ]
  },
  {
    id: 'SP-003',
    titulo: 'Seguridad del material electoral',
    descripcion: 'Coordinar con los oficiales de mayor grado de las FF.AA. y la PNP la seguridad del material electoral, equipos informáticos y actas electorales.',
    proceso: 'SP',
    fase: 'ejecucion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'SP-003-1', titulo: 'Coordinar seguridad del material', descripcion: 'Definir responsables de custodia', completada: false, orden: 1 },
      { id: 'SP-003-2', titulo: 'Coordinar seguridad de equipos informáticos', descripcion: 'Especial atención a equipos STAE', completada: false, orden: 2 },
      { id: 'SP-003-3', titulo: 'Coordinar seguridad de actas electorales', descripcion: 'Garantizar intangibilidad de actas', completada: false, orden: 3 }
    ]
  },

  // CAPACITACIÓN DEL PERSONAL DE LA ODPE (CPO)
  {
    id: 'CPO-001',
    titulo: 'Registro de asistencia a reuniones de reforzamiento',
    descripcion: 'Registrar su asistencia en el formato FM10-GOECOR/CPO: "Registro de asistencia de las reuniones de reforzamiento y de la jornada de entrenamiento".',
    proceso: 'CPO',
    fase: 'capacitacion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CPO-001-1', titulo: 'Asistir a 1ª reunión de reforzamiento', descripcion: 'Participar activamente y firmar asistencia', completada: false, orden: 1 },
      { id: 'CPO-001-2', titulo: 'Asistir a 2ª reunión de reforzamiento', descripcion: 'Participar activamente y firmar asistencia', completada: false, orden: 2 },
      { id: 'CPO-001-3', titulo: 'Asistir a 3ª reunión de reforzamiento', descripcion: 'Participar activamente y firmar asistencia', completada: false, orden: 3 }
    ],
    documentos: ['FM10-GOECOR/CPO - Registro de asistencia']
  },
  {
    id: 'CPO-002',
    titulo: 'Participación en jornadas de entrenamiento',
    descripcion: 'Participar de manera proactiva y responsable en las jornadas de entrenamiento programadas.',
    proceso: 'CPO',
    fase: 'capacitacion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CPO-002-1', titulo: 'Practicar acondicionamiento del centro de acopio', descripcion: 'Ejercicio práctico de organización', completada: false, orden: 1 },
      { id: 'CPO-002-2', titulo: 'Practicar traslado de sobres al centro de acopio', descripcion: 'Simulación de traslado de materiales', completada: false, orden: 2 },
      { id: 'CPO-002-3', titulo: 'Practicar uso de formatos correspondientes', descripcion: 'Manejo correcto de documentación', completada: false, orden: 3 }
    ]
  },
  {
    id: 'CPO-003',
    titulo: 'Evaluaciones de capacitación',
    descripcion: 'Rendir la evaluación correspondiente al término de cada reunión de reforzamiento.',
    proceso: 'CPO',
    fase: 'capacitacion',
    prioridad: 'media',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CPO-003-1', titulo: 'Evaluación 1ª reunión', descripcion: 'Comprobar comprensión de contenidos', completada: false, orden: 1 },
      { id: 'CPO-003-2', titulo: 'Evaluación 2ª reunión', descripcion: 'Comprobar comprensión de contenidos', completada: false, orden: 2 },
      { id: 'CPO-003-3', titulo: 'Evaluación 3ª reunión', descripcion: 'Comprobar comprensión de contenidos', completada: false, orden: 3 }
    ]
  },

  // CAPACITACIÓN DE ACTORES ELECTORALES (CAE)
  {
    id: 'CAE-001',
    titulo: 'Apoyo en organización de jornadas de capacitación',
    descripcion: 'Apoyar en la organización y desarrollo de las jornadas de capacitación dirigidas a los miembros de mesa.',
    proceso: 'CAE',
    fase: 'capacitacion',
    fechaInicio: '2026-03-29',
    fechaFin: '2026-04-05',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CAE-001-1', titulo: 'Primera jornada de capacitación', descripcion: 'Domingo 29 de marzo de 2026', completada: false, orden: 1 },
      { id: 'CAE-001-2', titulo: 'Segunda jornada de capacitación', descripcion: 'Domingo 5 de abril de 2026', completada: false, orden: 2 },
      { id: 'CAE-001-3', titulo: 'Registro de capacitación en FM06-GOECOR/CAE', descripcion: 'Registrar a cada miembro de mesa capacitado', completada: false, orden: 3 }
    ],
    documentos: ['FM06-GOECOR/CAE - Registro de capacitación de miembros de mesa']
  },
  {
    id: 'CAE-002',
    titulo: 'Distribución de materiales de capacitación',
    descripcion: 'Apoyar en la distribución de los materiales de capacitación y de difusión electoral.',
    proceso: 'CAE',
    fase: 'capacitacion',
    prioridad: 'media',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CAE-002-1', titulo: 'Distribuir manual de instrucciones para miembros de mesa', descripcion: 'Entregar a cada miembro de mesa', completada: false, orden: 1 },
      { id: 'CAE-002-2', titulo: 'Colocar afiches de jornada de capacitación', descripcion: 'Ubicar en lugares visibles', completada: false, orden: 2 },
      { id: 'CAE-002-3', titulo: 'Distribuir cartillas del elector', descripcion: 'Material de difusión electoral', completada: false, orden: 3 }
    ]
  },
  {
    id: 'CAE-003',
    titulo: 'Supervisión del local de capacitación',
    descripcion: 'Supervisar que el local de la jornada de capacitación cumpla con todos los criterios establecidos.',
    proceso: 'CAE',
    fase: 'capacitacion',
    prioridad: 'media',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CAE-003-1', titulo: 'Verificar ingreso al local', descripcion: 'Cartel identificativo y personal de recepción', completada: false, orden: 1 },
      { id: 'CAE-003-2', titulo: 'Verificar aulas', descripcion: 'Mobiliario ordenado y material disponible', completada: false, orden: 2 },
      { id: 'CAE-003-3', titulo: 'Verificar equipos STAE', descripcion: 'Equipos habilitados y listos', completada: false, orden: 3 },
      { id: 'CAE-003-4', titulo: 'Completar FM12-GOECOR/CAE', descripcion: 'Supervisión del local de la jornada de capacitación', completada: false, orden: 4 }
    ],
    documentos: ['FM12-GOECOR/CAE - Supervisión del local de la jornada de capacitación']
  },

  // CONFORMACIÓN DE MESAS DE SUFRAGIO (CMS)
  {
    id: 'CMS-001',
    titulo: 'Reconocimiento del local de votación',
    descripcion: 'Efectuar el reconocimiento y/o verificación del local o de los locales de votación del distrito.',
    proceso: 'CMS',
    fase: 'organizacion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CMS-001-1', titulo: 'Recibir formatos del coordinador distrital', descripcion: 'FM02, FM07 y FM04 para cada local', completada: false, orden: 1 },
      { id: 'CMS-001-2', titulo: 'Coordinar visita con representante del LV', descripcion: 'Agendar fecha y hora de visita', completada: false, orden: 2 },
      { id: 'CMS-001-3', titulo: 'Verificar disponibilidad del local', descripcion: 'Confirmar que el local estará disponible', completada: false, orden: 3 },
      { id: 'CMS-001-4', titulo: 'Contar aulas por piso y pabellón', descripcion: 'Identificar capacidad del local', completada: false, orden: 5 },
      { id: 'CMS-001-5', titulo: 'Identificar ambientes especiales', descripcion: 'CA, PT, MTV, FF.AA. y armería', completada: false, orden: 6 }
    ],
    documentos: ['FM02-GOECOR/CMS - Ficha de verificación de local', 'FM07-GOECOR/CMS - Acta de conformidad', 'FM04-GOECOR/CMS - Croquis del local']
  },
  {
    id: 'CMS-002',
    titulo: 'Elaboración del croquis del local',
    descripcion: 'Elaborar el croquis del local en el FM04-GOECOR/CMS.',
    proceso: 'CMS',
    fase: 'organizacion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CMS-002-1', titulo: 'Dibujar perímetro del local', descripcion: 'Orientar desde la puerta principal', completada: false, orden: 1 },
      { id: 'CMS-002-2', titulo: 'Señalar pabellones', descripcion: 'Diferenciar pisos (100, 200, 300)', completada: false, orden: 2 },
      { id: 'CMS-002-3', titulo: 'Identificar aulas', descripcion: 'Numerar correlativamente por pabellón', completada: false, orden: 3 },
      { id: 'CMS-002-4', titulo: 'Incluir nombre y dirección del local', descripcion: 'Datos identificativos', completada: false, orden: 4 },
      { id: 'CMS-002-5', titulo: 'Marcar puertas de ingreso y salida', descripcion: 'Indicar escaleras y accesos', completada: false, orden: 5 }
    ],
    documentos: ['FM04-GOECOR/CMS - Croquis del local de votación', 'Anexo 1 - Instrucciones para elaborar croquis']
  },
  {
    id: 'CMS-003',
    titulo: 'Elaboración del maestro de mesas',
    descripcion: 'Registrar la ubicación de los ambientes en el Maestro de Mesas de Sufragio (FM05-GOECOR/CMS).',
    proceso: 'CMS',
    fase: 'organizacion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CMS-003-1', titulo: 'Asignar mesas por aula', descripcion: 'Una mesa por aula', completada: false, orden: 1 },
      { id: 'CMS-003-2', titulo: 'Asignar mesas por piso', descripcion: 'Distribución equilibrada', completada: false, orden: 2 },
      { id: 'CMS-003-3', titulo: 'Asignar mesas por pabellón', descripcion: 'Organización lógica', completada: false, orden: 3 },
      { id: 'CMS-003-4', titulo: 'Validar con coordinador de operaciones', descripcion: 'Entregar versión final', completada: false, orden: 4 }
    ],
    documentos: ['FM05-GOECOR/CMS - Maestro de mesas de sufragio']
  },

  // DESIGNACIÓN DE MIEMBROS DE MESA (DMM)
  {
    id: 'DMM-001',
    titulo: 'Verificación de designación de miembros de mesa',
    descripcion: 'Verificar que se haya completado la designación de miembros de mesa para todas las mesas del local.',
    proceso: 'DMM',
    fase: 'organizacion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'DMM-001-1', titulo: 'Verificar presidente de mesa', descripcion: 'Confirmar designación', completada: false, orden: 1 },
      { id: 'DMM-001-2', titulo: 'Verificar secretario de mesa', descripcion: 'Confirmar designación', completada: false, orden: 2 },
      { id: 'DMM-001-3', titulo: 'Verificar tercer miembro de mesa', descripcion: 'Confirmar designación', completada: false, orden: 3 },
      { id: 'DMM-001-4', titulo: 'Verificar suplentes', descripcion: 'Primer, segundo y tercer suplente', completada: false, orden: 4 }
    ]
  },

  // DESPLIEGUE DE MATERIAL DE SUFRAGIO (DMS)
  {
    id: 'DMS-001',
    titulo: 'Recepción del material electoral',
    descripcion: 'Recibir del coordinador distrital el material de sufragio, paquete con señales, ánforas, paquete del CLV, refrigerios y cabinas.',
    proceso: 'DMS',
    fase: 'ejecucion',
    fechaLimite: '2026-04-11',
    prioridad: 'alta',
    completada: false,
    alertaActiva: true,
    subActividades: [
      { id: 'DMS-001-1', titulo: 'Recibir material de sufragio', descripcion: 'Verificar cantidad correcta', completada: false, orden: 1 },
      { id: 'DMS-001-2', titulo: 'Recibir material de reserva', descripcion: 'Material de contingencia', completada: false, orden: 2 },
      { id: 'DMS-001-3', titulo: 'Recibir paquete del CLV', descripcion: 'Documentos y materiales del coordinador', completada: false, orden: 3 },
      { id: 'DMS-001-4', titulo: 'Recibir señales para el local', descripcion: 'Rótulos y señalización', completada: false, orden: 4 },
      { id: 'DMS-001-5', titulo: 'Recibir ánforas', descripcion: 'Verificar cantidad', completada: false, orden: 5 },
      { id: 'DMS-001-6', titulo: 'Recibir cabinas de votación', descripcion: 'Verificar cantidad', completada: false, orden: 6 },
      { id: 'DMS-001-7', titulo: 'Recibir refrigerios de miembros de mesa', descripcion: 'Verificar cantidad', completada: false, orden: 7 },
      { id: 'DMS-001-8', titulo: 'Firmar FM06-GOECOR/DMS', descripcion: 'Constancia de recepción', completada: false, orden: 8 }
    ],
    documentos: ['FM06-GOECOR/DMS - Constancia de recepción del material']
  },
  {
    id: 'DMS-002',
    titulo: 'Verificación del material recibido',
    descripcion: 'Verificar que el material recibido corresponda a las mesas de sufragio del local de votación asignado.',
    proceso: 'DMS',
    fase: 'ejecucion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'DMS-002-1', titulo: 'Verificar coincidencia de números de mesa', descripcion: 'Coincidir con maestro de mesas', completada: false, orden: 1 },
      { id: 'DMS-002-2', titulo: 'Verificar integridad de cajas', descripcion: 'Revisar sellos y estado', completada: false, orden: 2 },
      { id: 'DMS-002-3', titulo: 'Reportar discrepancias', descripcion: 'Informar al CD/CCP si hay diferencias', completada: false, orden: 3 }
    ]
  },
  {
    id: 'DMS-003',
    titulo: 'Traslado al centro de acopio',
    descripcion: 'Trasladar al centro de acopio el material de sufragio, los refrigerios y otros materiales electorales.',
    proceso: 'DMS',
    fase: 'ejecucion',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'DMS-003-1', titulo: 'Organizar traslado', descripcion: 'Coordinar logística', completada: false, orden: 1 },
      { id: 'DMS-003-2', titulo: 'Verificar presencia de FF.AA. o PNP', descripcion: 'Material solo se entrega con custodia', completada: false, orden: 2 },
      { id: 'DMS-003-3', titulo: 'Acondicionar centro de acopio', descripcion: 'Organizar material de manera ordenada', completada: false, orden: 3 }
    ]
  },
  {
    id: 'DMS-004',
    titulo: 'Recepción de equipos informáticos (STAE)',
    descripcion: 'En caso de implementarse STAE, recibir los equipos informáticos electorales.',
    proceso: 'DMS',
    fase: 'ejecucion',
    prioridad: 'media',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'DMS-004-1', titulo: 'Recibir laptops', descripcion: 'Verificar código patrimonial', completada: false, orden: 1 },
      { id: 'DMS-004-2', titulo: 'Recibir impresoras', descripcion: 'Verificar código patrimonial', completada: false, orden: 2 },
      { id: 'DMS-004-3', titulo: 'Recibir tablets', descripcion: 'Verificar código patrimonial', completada: false, orden: 3 },
      { id: 'DMS-004-4', titulo: 'Recibir equipos de conectividad', descripcion: 'BGAN, modem, inversor', completada: false, orden: 4 },
      { id: 'DMS-004-5', titulo: 'Firmar FM08-GOECOR/DMS', descripcion: 'Constancia de recepción de equipos', completada: false, orden: 5 }
    ],
    documentos: ['FM08-GOECOR/DMS - Constancia de recepción de equipos informáticos']
  },

  // JORNADA ELECTORAL (JEL)
  {
    id: 'JEL-001',
    titulo: 'Acondicionamiento del centro de acopio',
    descripcion: 'Acondicionar el centro de acopio en los turnos de mañana y tarde.',
    proceso: 'JEL',
    fase: 'ejecucion',
    fechaInicio: '2026-04-12',
    fechaFin: '2026-04-12',
    prioridad: 'alta',
    completada: false,
    alertaActiva: true,
    subActividades: [
      { id: 'JEL-001-1', titulo: 'Turno de mañana: Acondicionar centro de acopio', descripcion: 'Organizar espacio para recepción de materiales', completada: false, orden: 1 },
      { id: 'JEL-001-2', titulo: 'Turno de tarde: Acondicionar centro de acopio', descripcion: 'Preparar para recepción de materiales de segunda vuelta', completada: false, orden: 2 }
    ]
  },
  {
    id: 'JEL-002',
    titulo: 'Señalización y acondicionamiento del local',
    descripcion: 'Dirigir, organizar y supervisar el acondicionamiento del local de votación conforme a la señalización establecida.',
    proceso: 'JEL',
    fase: 'ejecucion',
    fechaInicio: '2026-04-12',
    prioridad: 'alta',
    completada: false,
    alertaActiva: true,
    subActividades: [
      { id: 'JEL-002-1', titulo: 'Colocar banner de bienvenida', descripcion: 'En el ingreso del local', completada: false, orden: 1 },
      { id: 'JEL-002-2', titulo: 'Colocar gigantografías de mesas', descripcion: 'Listado de electores por orden alfabético', completada: false, orden: 2 },
      { id: 'JEL-002-3', titulo: 'Señalizar ingreso y salida', descripcion: 'Marcar rutas con flechas', completada: false, orden: 3 },
      { id: 'JEL-002-4', titulo: 'Señalizar mesas para personas con discapacidad', descripcion: 'Identificar ubicación accesible', completada: false, orden: 4 },
      { id: 'JEL-002-5', titulo: 'Señalizar centro de acopio', descripcion: 'Zona restringida', completada: false, orden: 5 },
      { id: 'JEL-002-6', titulo: 'Señalizar módulo temporal de votación', descripcion: 'Si corresponde', completada: false, orden: 7 },
      { id: 'JEL-002-7', titulo: 'Señalizar punto de transmisión (STAE)', descripcion: 'Si corresponde', completada: false, orden: 8 },
      { id: 'JEL-002-8', titulo: 'Completar FM02-GOECOR/JEL', descripcion: 'Lista de chequeo de acondicionamiento', completada: false, orden: 9 }
    ],
    documentos: ['FM02-GOECOR/JEL - Lista de chequeo de acondicionamiento del local']
  },
  {
    id: 'JEL-003',
    titulo: 'Entrega de material a coordinadores de mesa',
    descripcion: 'Entregar el material electoral y los refrigerios a los coordinadores de mesa (CM) una vez conformada la mesa de sufragio.',
    proceso: 'JEL',
    fase: 'ejecucion',
    fechaInicio: '2026-04-12',
    prioridad: 'alta',
    completada: false,
    alertaActiva: true,
    subActividades: [
      { id: 'JEL-003-1', titulo: 'Verificar conformación de mesa', descripcion: 'Confirmar que la mesa está completa', completada: false, orden: 1 },
      { id: 'JEL-003-2', titulo: 'Entregar material de sufragio', descripcion: 'Caja correspondiente a la mesa', completada: false, orden: 2 },
      { id: 'JEL-003-3', titulo: 'Entregar refrigerios', descripcion: 'Para miembros de mesa', completada: false, orden: 3 }
    ]
  },
  {
    id: 'JEL-004',
    titulo: 'Atención a fiscalizadores y observadores',
    descripcion: 'Atender a los fiscalizadores, observadores, medios de comunicación, personeros y autoridades.',
    proceso: 'JEL',
    fase: 'ejecucion',
    fechaInicio: '2026-04-12',
    prioridad: 'media',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'JEL-004-1', titulo: 'Registrar ingreso de personeros', descripcion: 'Verificar acreditación', completada: false, orden: 1 },
      { id: 'JEL-004-2', titulo: 'Atender a fiscalizadores', descripcion: 'Brindar información solicitada', completada: false, orden: 2 },
      { id: 'JEL-004-3', titulo: 'Atender a observadores', descripcion: 'Facilitar labor de observación', completada: false, orden: 3 },
      { id: 'JEL-004-4', titulo: 'Coordinar con medios de comunicación', descripcion: 'Según protocolo establecido', completada: false, orden: 4 }
    ]
  },
  {
    id: 'JEL-005',
    titulo: 'Orientación a electores',
    descripcion: 'Orientar a los electores durante el desarrollo de la jornada electoral, brindando información clara y oportuna sobre el ingreso, el tránsito y la ubicación de sus mesas.',
    proceso: 'JEL',
    fase: 'ejecucion',
    fechaInicio: '2026-04-12',
    prioridad: 'alta',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'JEL-005-1', titulo: 'Informar ubicación de mesas', descripcion: 'Usar gigantografías como referencia', completada: false, orden: 1 },
      { id: 'JEL-005-2', titulo: 'Orientar sobre rutas de acceso', descripcion: 'Indicar ingreso y salida', completada: false, orden: 2 },
      { id: 'JEL-005-3', titulo: 'Atender a personas con discapacidad', descripcion: 'Dirigir a mesas accesibles o MTV', completada: false, orden: 3 },
      { id: 'JEL-005-4', titulo: 'Brindar atención preferente', descripcion: 'Gestantes, adultos mayores, personas con niños', completada: false, orden: 4 }
    ]
  },
  {
    id: 'JEL-006',
    titulo: 'Recepción de documentos y materiales',
    descripcion: 'Recibir de los coordinadores de mesa los documentos, materiales, restos electorales y los EIE (en caso de STAE).',
    proceso: 'JEL',
    fase: 'ejecucion',
    fechaInicio: '2026-04-12',
    prioridad: 'alta',
    completada: false,
    alertaActiva: true,
    subActividades: [
      { id: 'JEL-006-1', titulo: 'Recibir actas electorales', descripcion: 'Verificar integridad', completada: false, orden: 1 },
      { id: 'JEL-006-2', titulo: 'Recibir sobres con cédulas', descripcion: 'Sobres 01, 02, 03 y 04', completada: false, orden: 2 },
      { id: 'JEL-006-3', titulo: 'Recibir restos electorales', descripcion: 'Cédulas no usadas y material sobrante', completada: false, orden: 3 },
      { id: 'JEL-006-4', titulo: 'Recibir equipos informáticos (STAE)', descripcion: 'Laptops, impresoras, tablets', completada: false, orden: 4 },
      { id: 'JEL-006-5', titulo: 'Verificar orden y completitud', descripcion: 'Revisar que nada falte', completada: false, orden: 5 }
    ]
  },
  {
    id: 'JEL-007',
    titulo: 'Entrega del local de votación',
    descripcion: 'Entregar el local de votación en las mismas condiciones en que fue recibido.',
    proceso: 'JEL',
    fase: 'ejecucion',
    fechaInicio: '2026-04-12',
    prioridad: 'media',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'JEL-007-1', titulo: 'Retirar toda la señalización', descripcion: 'Dejar el local limpio', completada: false, orden: 1 },
      { id: 'JEL-007-2', titulo: 'Verificar estado de aulas', descripcion: 'Confirmar que no hay daños', completada: false, orden: 2 },
      { id: 'JEL-007-3', titulo: 'Entregar al representante del local', descripcion: 'Firmar acta de entrega', completada: false, orden: 3 }
    ]
  },

  // REPLIEGUE DE MATERIAL ELECTORAL (RME)
  {
    id: 'RME-001',
    titulo: 'Traslado de materiales a la ODPE',
    descripcion: 'Trasladar y entregar en la línea de recepción de la ODPE los documentos y materiales electorales.',
    proceso: 'RME',
    fase: 'cierre',
    fechaInicio: '2026-04-12',
    prioridad: 'alta',
    completada: false,
    alertaActiva: true,
    subActividades: [
      { id: 'RME-001-1', titulo: 'Organizar materiales en centro de acopio', descripcion: 'Ordenar por mesas', completada: false, orden: 1 },
      { id: 'RME-001-2', titulo: 'Verificar integridad de sobres', descripcion: 'Confirmar sellos intactos', completada: false, orden: 2 },
      { id: 'RME-001-3', titulo: 'Coordinar traslado con seguridad', descripcion: 'FF.AA. y PNP', completada: false, orden: 3 },
      { id: 'RME-001-4', titulo: 'Entregar en línea de recepción de ODPE', descripcion: 'Seguir protocolo establecido', completada: false, orden: 4 }
    ]
  },

  // CIERRE DE LA ODPE (CIO)
  {
    id: 'CIO-001',
    titulo: 'Cierre de actividades',
    descripcion: 'Finalizar todas las actividades operativas asignadas al CLV.',
    proceso: 'CIO',
    fase: 'cierre',
    prioridad: 'media',
    completada: false,
    alertaActiva: false,
    subActividades: [
      { id: 'CIO-001-1', titulo: 'Entregar informes finales', descripcion: 'Completar documentación requerida', completada: false, orden: 1 },
      { id: 'CIO-001-2', titulo: 'Devolver materiales de trabajo', descripcion: 'Entregar fotocheck y materiales', completada: false, orden: 2 },
      { id: 'CIO-001-3', titulo: 'Confirmar asistencia final', descripcion: 'Registrar asistencia al cierre', completada: false, orden: 3 }
    ]
  }
];

export const fechasImportantes: FechaImportante[] = [
  { fecha: '2026-03-29', titulo: 'Primera Jornada de Capacitación', descripcion: 'Primera jornada de capacitación para miembros de mesa', tipo: 'inicio' },
  { fecha: '2026-04-05', titulo: 'Segunda Jornada de Capacitación', descripcion: 'Segunda jornada de capacitación para miembros de mesa', tipo: 'inicio' },
  { fecha: '2026-04-11', titulo: 'Despliegue de Material Electoral', descripcion: 'Fecha límite para recepción del material electoral en locales', tipo: 'limite' },
  { fecha: '2026-04-12', titulo: 'JORNADA ELECTORAL', descripcion: 'Elecciones Generales 2026 - Día de la jornada electoral', tipo: 'jornada' },
  { fecha: '2026-04-12', titulo: 'Inicio de Votación', descripcion: 'Apertura de mesas de sufragio a las 7:00 a.m.', tipo: 'inicio' },
  { fecha: '2026-04-12', titulo: 'Cierre de Votación', descripcion: 'Cierre de mesas de sufragio a las 5:00 p.m.', tipo: 'fin' }
];

export const alertasIniciales: Alerta[] = [
  {
    id: 'ALT-001',
    tipo: 'info',
    titulo: 'Bienvenido a la Guía del CLV',
    mensaje: 'Esta aplicación te guiará en todas las actividades que debes realizar como Coordinador de Local de Votación durante las Elecciones Generales 2026.',
    fecha: new Date().toISOString(),
    leida: false
  },
  {
    id: 'ALT-002',
    tipo: 'warning',
    titulo: 'Jornada Electoral próxima',
    mensaje: 'La jornada electoral será el 12 de abril de 2026. Asegúrate de completar todas las actividades previas.',
    fecha: new Date().toISOString(),
    leida: false
  }
];
