import { useState } from 'react';
import { 
  LayoutDashboard, 
  ListTodo, 
  Bell, 
  Calendar, 
  BookOpen,
  Menu,
  User,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useActividades } from '@/hooks/useActividades';
import { Dashboard } from '@/sections/Dashboard';
import { ActividadesList } from '@/sections/ActividadesList';
import { AlertasPanel } from '@/sections/AlertasPanel';
import { CalendarioElectoral } from '@/sections/CalendarioElectoral';
import { GuiaProcesos } from '@/sections/GuiaProcesos';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

type Vista = 'dashboard' | 'actividades' | 'alertas' | 'calendario' | 'guia';

const menuItems: { id: Vista; label: string; icon: React.ElementType }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'actividades', label: 'Actividades', icon: ListTodo },
  { id: 'alertas', label: 'Alertas', icon: Bell },
  { id: 'calendario', label: 'Calendario', icon: Calendar },
  { id: 'guia', label: 'Guía de Procesos', icon: BookOpen },
];

function App() {
  const [vistaActual, setVistaActual] = useState<Vista>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const {
    actividades,
    actividadesUrgentes,
    actividadesProximas,
    alertas,
    estadisticas,
    toggleActividad,
    toggleSubActividad,
    marcarAlertaLeida,
    eliminarAlerta
  } = useActividades();

  const alertasPendientes = alertas.filter(a => !a.leida).length;

  const handleToggleActividad = (id: string) => {
    toggleActividad(id);
    const actividad = actividades.find(a => a.id === id);
    if (actividad) {
      const nuevoEstado = !actividad.completada;
      toast.success(
        nuevoEstado 
          ? `✅ "${actividad.titulo}" marcada como completada` 
          : `⏳ "${actividad.titulo}" marcada como pendiente`
      );
    }
  };

  const handleToggleSubActividad = (actividadId: string, subId: string) => {
    toggleSubActividad(actividadId, subId);
  };

  const handleMarcarAlertaLeida = (id: string) => {
    marcarAlertaLeida(id);
    toast.info('Alerta marcada como leída');
  };

  const handleEliminarAlerta = (id: string) => {
    eliminarAlerta(id);
    toast.info('Alerta eliminada');
  };

  const handleVerActividad = (_actividadId: string) => {
    setVistaActual('actividades');
    // Aquí se podría agregar lógica para expandir la actividad específica
  };

  const renderVista = () => {
    switch (vistaActual) {
      case 'dashboard':
        return (
          <Dashboard 
            estadisticas={estadisticas}
            actividadesUrgentes={actividadesUrgentes.length}
            actividadesProximas={actividadesProximas.length}
            alertasPendientes={alertasPendientes}
            onVerTodasActividades={() => setVistaActual('actividades')}
            onVerAlertas={() => setVistaActual('alertas')}
          />
        );
      case 'actividades':
        return (
          <ActividadesList 
            actividades={actividades}
            onToggleActividad={handleToggleActividad}
            onToggleSubActividad={handleToggleSubActividad}
          />
        );
      case 'alertas':
        return (
          <AlertasPanel 
            alertas={alertas}
            actividadesUrgentes={actividadesUrgentes}
            actividadesProximas={actividadesProximas}
            onMarcarLeida={handleMarcarAlertaLeida}
            onEliminar={handleEliminarAlerta}
            onVerActividad={handleVerActividad}
          />
        );
      case 'calendario':
        return <CalendarioElectoral />;
      case 'guia':
        return <GuiaProcesos />;
      default:
        return null;
    }
  };

  const SidebarContent = () => (
    <>
      {/* Logo */}
      <div className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">ON</span>
          </div>
          <div>
            <h1 className="font-bold text-slate-900 leading-tight">Guía CLV</h1>
            <p className="text-xs text-slate-500">Elecciones 2026</p>
          </div>
        </div>
      </div>

      <Separator />

      {/* User Info */}
      <div className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center">
            <User className="h-5 w-5 text-slate-500" />
          </div>
          <div>
            <p className="font-medium text-sm text-slate-900">Coordinador CLV</p>
            <Badge variant="outline" className="text-xs bg-red-50 text-red-700 border-red-200">
              CLV/RLV
            </Badge>
          </div>
        </div>
      </div>

      <Separator />

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = vistaActual === item.id;
          const isAlertas = item.id === 'alertas';
          
          return (
            <button
              key={item.id}
              onClick={() => {
                setVistaActual(item.id);
                setSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive 
                  ? 'bg-red-50 text-red-700' 
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="flex-1 text-left">{item.label}</span>
              {isAlertas && alertasPendientes > 0 && (
                <Badge className="bg-red-500 text-white text-xs">
                  {alertasPendientes}
                </Badge>
              )}
              {isActive && <ChevronRight className="h-4 w-4" />}
            </button>
          );
        })}
      </nav>

      <Separator />

      {/* Footer */}
      <div className="p-4">
        <div className="bg-slate-50 rounded-lg p-3">
          <p className="text-xs text-slate-500 mb-2">Progreso General</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-red-500 transition-all duration-500"
                style={{ width: `${estadisticas.progresoGeneral}%` }}
              />
            </div>
            <span className="text-xs font-medium text-slate-700">
              {estadisticas.progresoGeneral}%
            </span>
          </div>
        </div>
        <p className="text-xs text-slate-400 mt-3 text-center">
          © 2026 ONPE - Guía del CLV
        </p>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Toaster position="top-right" richColors />
      
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-slate-200 fixed h-full">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-64 p-0">
          <div className="flex flex-col h-full">
            <SidebarContent />
          </div>
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64">
        {/* Mobile Header */}
        <header className="lg:hidden bg-white border-b border-slate-200 sticky top-0 z-10">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-64 p-0">
                  <div className="flex flex-col h-full">
                    <SidebarContent />
                  </div>
                </SheetContent>
              </Sheet>
              <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">ON</span>
              </div>
              <span className="font-bold text-slate-900">Guía CLV</span>
            </div>
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 text-xs">
              {estadisticas.progresoGeneral}%
            </Badge>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
          {renderVista()}
        </div>
      </main>
    </div>
  );
}

export default App;
